import pandas as pd
import torch.optim as optim
import torch.nn as nn
import torch
from net import Net
import numpy as np
import pandas as pd
import random
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torchvision import datasets, transforms
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_curve, auc,f1_score,matthews_corrcoef,roc_auc_score,precision_score,accuracy_score
import matplotlib.pyplot as plt
#data:需要进行分割的数据集
#random_state:设置随机种子，保证每次运行生成相同的随机数
#test_size:将数据分割成训练集的比例
# 读取数据
data = pd.read_csv('output/transformed_trainset.csv', header=0, encoding='gb18030')
data = np.mat(data)
#data = np.delete(data, 0, axis=1)
dat=data[:,:777]
label=data[:,-1]
def norm(data):
    return (data-np.min(data))/(np.max(data)-np.min(data))
for i in range(dat.shape[1]):
    dat[:,i]=norm(dat[:,i])
Acc=[] #存放acc的值
f1=[] #存放f1的值
MCC=[] #存放mcc的值
sen=[] #存放sen的值
roc_auc=[] #存放auc的值
Fpr=[]
Tpr=[] ###存放真正率和假正率
class AccDataset(Dataset):
    def __init__(self, traindata,label):
        self.data = traindata
        self.label = label
        self.len = len(self.data[:,1])
    def __len__(self):
        return self.len
    def __getitem__(self, idx):
        x = self.data[idx,:]
        label = self.label[idx,:]
        return x.unsqueeze(0),label.long().item()

def test():
    output=res(testdata.unsqueeze(1))
    _,y_score=torch.max(output.data,dim=1)
    y_score=y_score.numpy()
    return accuracy_score(y_test, y_score)
for i in range(5):
    X_train,X_test,y_train,y_test= train_test_split(dat,label,test_size=0.04)
    traindata = torch.from_numpy(X_train).type('torch.DoubleTensor')
    trainlabel = torch.from_numpy(y_train).type('torch.DoubleTensor')
    testdata = torch.from_numpy(X_test).type('torch.DoubleTensor')
    testlabel = torch.from_numpy(y_test).type('torch.DoubleTensor')
    res = Net().double()
    dataset=AccDataset(traindata,trainlabel)
    train_loader=DataLoader(dataset=dataset,batch_size=8,shuffle=True,num_workers=0)
    #res.load_state_dict(torch.load('res.pt'))
    optimizer = optim.Adam(res.parameters(), lr=5e-6)
    loss_fn=torch.nn.CrossEntropyLoss()
    t_loss=0
    for epoch in range(1000):
        for da,la in train_loader:
            da = da
            la = la
            preds = res(da)
            loss = loss_fn(preds, la)
            res.zero_grad()
            loss.backward()
            t_loss+=loss.item()
            optimizer.step()
        print("loss:{}".format(t_loss/(len(dataset)//8)))
        t_loss=0
        if test()>0.95:
            break
    print('done')
    #torch.save(res.state_dict(), "model/res{}.pt".format(i+1))
    output=res(testdata.unsqueeze(1))
    _,y_score=torch.max(output.data,dim=1)
    y_score=y_score.numpy()
    softmax_func=nn.Softmax(dim=1)
    y_s=softmax_func(output)
    y_test=np.array(y_test).flatten()
    yss=[]
    for idx,i in enumerate(y_test.astype(int)):
        yss.append(y_s.detach().numpy()[idx][1])
    fpr,tpr,threshold = roc_curve(y_test, np.array(yss)) ###计算真正率和假正率
    f1.append(f1_score(y_test, y_score, average='macro')) 
    Acc.append(accuracy_score(y_test, y_score))
    print(accuracy_score(y_test, y_score))
    sen.append(precision_score(y_test, y_score, average='macro') )
    MCC.append(matthews_corrcoef(y_test, y_score))
    Fpr.append(fpr)
    Tpr.append(tpr)
    fpr1,tpr1,threshold1 = roc_curve(y_test, y_score)
    roc_auc.append(auc(fpr1,tpr1)) ###计算auc的值

for i in range(5):
    X_train,X_test,y_train,y_test= train_test_split(dat,label,test_size=0.3)
    traindata = torch.from_numpy(X_train).type('torch.DoubleTensor')
    trainlabel = torch.from_numpy(y_train).type('torch.DoubleTensor')
    testdata = torch.from_numpy(X_test).type('torch.DoubleTensor')
    testlabel = torch.from_numpy(y_test).type('torch.DoubleTensor')
    res = Net().double()
    dataset=AccDataset(traindata,trainlabel)
    train_loader=DataLoader(dataset=dataset,batch_size=8,shuffle=True,num_workers=0)
    #res.load_state_dict(torch.load('res.pt'))
    optimizer = optim.Adam(res.parameters(), lr=5e-6)
    loss_fn=torch.nn.CrossEntropyLoss()
    t_loss=0
    for epoch in range(1000):
        for da,la in train_loader:
            da = da
            la = la
            preds = res(da)
            loss = loss_fn(preds, la)
            res.zero_grad()
            loss.backward()
            t_loss+=loss.item()
            optimizer.step()
        print("loss:{}".format(t_loss/(len(dataset)//8)))
        t_loss=0
        if test()>0.85:
            break
    print('done')
    #torch.save(res.state_dict(), "model/res{}.pt".format(i+1))
    output=res(testdata.unsqueeze(1))
    _,y_score=torch.max(output.data,dim=1)
    y_score=y_score.numpy()
    softmax_func=nn.Softmax(dim=1)
    y_s=softmax_func(output)
    y_test=np.array(y_test).flatten()
    yss=[]
    for idx,i in enumerate(y_test.astype(int)):
        yss.append(y_s.detach().numpy()[idx][1])
    fpr,tpr,threshold = roc_curve(y_test, np.array(yss)) ###计算真正率和假正率
    f1.append(f1_score(y_test, y_score, average='macro')) 
    Acc.append(accuracy_score(y_test, y_score))
    print(accuracy_score(y_test, y_score))
    sen.append(precision_score(y_test, y_score, average='macro') )
    MCC.append(matthews_corrcoef(y_test, y_score))
    Fpr.append(fpr)
    Tpr.append(tpr)
    fpr1,tpr1,threshold1 = roc_curve(y_test, y_score)
    roc_auc.append(auc(fpr1,tpr1)) ###计算auc的值   
plt.figure()
lw = 2
figsize = 16,10
figure,ax = plt.subplots(figsize=figsize)
for i in range(5):
    plt.plot(Fpr[i], Tpr[i], 
             lw=lw, label='fold%0.0f with RESCDA model(area = %0.4f)' % (int(i+1),roc_auc[i])) ###假正率为横坐标，真正率为纵坐标做曲线

for i in range(5):
    plt.plot(Fpr[i+5], Tpr[i+5], 
             lw=lw, linestyle='--', label='fold%0.0f with CNN model(area = %0.4f)' % (int(i+1),roc_auc[i+5])) ###假正率为横坐标，真正率为纵坐标做曲线
fontcn = {'family': 'Times New Roman','size': 24}
plt.tick_params(labelsize=18)
labels = ax.get_xticklabels() + ax.get_yticklabels()
[label.set_fontname('Times New Roman') for label in labels]
plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.0])
fontcn = {'family': 'Times New Roman','size': 24}
plt.tick_params(labelsize=18)
labels = ax.get_xticklabels() + ax.get_yticklabels()
[label.set_fontname('Times New Roman') for label in labels]
plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
plt.xlim([-0.1, 1.1])
plt.ylim([-0.1, 1.1])
plt.xlabel('1-Specificity',fontcn)
plt.ylabel('Sensitivity',fontcn)
plt.title('Receiver operating characteristic example',fontcn)
font1 = {'size': 18} 
plt.legend(prop=font1)




 
plt.savefig('tessstttyyy.png', dpi=800)

print('Accu.:',Acc,np.mean(Acc),np.std(Acc))
print('Sen.:',sen,np.mean(sen),np.std(sen))
print('F1.:',f1,np.mean(f1),np.std(f1))
print('MCC:',MCC,np.mean(MCC),np.std(MCC))
print('AUC:',roc_auc,np.mean(roc_auc),np.std(roc_auc))