# -*- coding: utf-8 -*-
"""
Created on Tue Sep  7 10:52:43 2021

@author: ring
"""
import requests
import re
import os
url = 'https://www.mn52.com/meihuoxiezhen/'
res = requests.get(url)
print(res.text)
pattern = re.compile('class="item-media entry".*?src="(.*?)"',re.S)
results =re.findall(pattern,res.text)
print(results)
#os.mkdir('E:/Desktop/meinv')
for img in results:
    response = requests.get("https:"+img)
    with open('E:/meinv/{}'.format(img),'wb') as f:
        f.write(respense.content)