import torch.nn as nn
import torch

class Net(nn.Module):       #网络架构，输入参数为1*776的tensor
    def __init__(self):
        super(Net, self).__init__()
        self.layer1 =torch.nn.Sequential(nn.Conv1d(1,16,4,stride=2, padding=1),
                                         nn.BatchNorm1d(16),
                                         nn.LeakyReLU(0.2)) # 1 * 1024 -> 64 * 512
        self.layer2 =torch.nn.Sequential(nn.Conv1d(16,32,8,stride=2,padding=1),
                                         nn.BatchNorm1d(32),
                                         nn.LeakyReLU(0.2)) 
        self.layer3 =torch.nn.Sequential(nn.Conv1d(32,64,16,stride=2,padding=1),
                                         nn.BatchNorm1d(64),
                                         nn.LeakyReLU(0.2)) 
        self.layer4 =torch.nn.Sequential(nn.Conv1d(64,64,3,stride=1,padding=1),
                                         nn.BatchNorm1d(64),
                                         nn.LeakyReLU(0.2)) 
        self.layer5 =torch.nn.Sequential(nn.Conv1d(128,16,4,stride=2,padding=1),
                                         nn.BatchNorm1d(16),
                                         nn.LeakyReLU(0.2)) 
        self.layer6 =torch.nn.Sequential(nn.Linear(16*45,32),
                                         nn.LeakyReLU(0.2)) 
        self.layer8 =torch.nn.Sequential(nn.Linear(32,2)) 
    def forward(self, x):
        out = self.layer1(x)
        out = self.layer2(out)
        out = self.layer3(out)
        out = torch.cat((self.layer4(out),out),dim=1)
        out = self.layer5(out)
        out = out.view(-1,16*45)
        out = self.layer6(out)
        out = self.layer8(out)
        return out
    



'''
class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        
        self.layer1 =torch.nn.Sequential(nn.Linear(776,512),
                                         nn.Dropout(0.2),
                                         nn.LeakyReLU()) 
        self.layer2 =torch.nn.Sequential(nn.Linear(512,128),
                                         nn.Dropout(0.2),
                                         nn.LeakyReLU()) 
        self.layer3 =torch.nn.Sequential(nn.Linear(128,32),
                                         nn.Dropout(0.2),
                                         nn.LeakyReLU()) 
        self.layer4 =torch.nn.Sequential(nn.Linear(32,16),
                                         nn.LeakyReLU()) 
        self.layer5 =torch.nn.Sequential(nn.Linear(16,2)) 
    def forward(self, x):
        out = self.layer1(x)
        out = self.layer2(out)
        out = self.layer3(out)
        out = self.layer4(out)
        out = self.layer5(out)
        return out.squeeze(1)
    '''